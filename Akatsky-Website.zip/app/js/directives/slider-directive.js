app.directive('slider', function () {
    return{
        restrict: 'A',
        templateUrl: 'partials/directives/slider.html',
        controller: 'SliderController'
    }

});