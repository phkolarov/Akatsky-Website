app.controller('HomePageController', ['$scope','$location', '$route',function () {





}]);