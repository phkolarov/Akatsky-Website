app.controller('CurrentArticleController', ['$scope', '$routeParams',function ($scope,$routeParams) {



    console.log($routeParams)
}]);