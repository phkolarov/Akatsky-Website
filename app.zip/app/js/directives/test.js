app.directive('testd', function () {
    return{
        restrict: 'A',
        templateUrl: 'partials/directives/testd.html',
        controller: 'test'
    }

});