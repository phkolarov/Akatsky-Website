app.directive('footer', function () {

    return{
        restrict: 'A',
        templateUrl: 'partials/directives/footer.html'
    }
});