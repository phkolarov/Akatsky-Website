app.controller('test', ['$scope', function ($scope) {

$scope.test2 = '����2';

}]);